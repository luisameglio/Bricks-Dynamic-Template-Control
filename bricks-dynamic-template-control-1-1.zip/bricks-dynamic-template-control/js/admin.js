jQuery(document).ready(function($) {
    // Function to check if a rule is complete
    function isRuleComplete($rule) {
        const templateId = $rule.find('select[name^="bdtc_rules"][name$="[template_id]"]').val();
        const postTypes = $rule.find('select[name^="bdtc_rules"][name$="[post_types][]"]').val();
        
        // Check if template and at least one post type are selected
        if (!templateId || !postTypes || postTypes.length === 0) {
            return false;
        }
        
        return true;
    }

    // Function to highlight incomplete fields
    function highlightIncompleteFields($rule) {
        $rule.find('.bdtc-field').removeClass('bdtc-field-error');
        
        const $templateField = $rule.find('select[name^="bdtc_rules"][name$="[template_id]"]').closest('.bdtc-field');
        const $postTypesField = $rule.find('select[name^="bdtc_rules"][name$="[post_types][]"]').closest('.bdtc-field');
        
        if (!$rule.find('select[name^="bdtc_rules"][name$="[template_id]"]').val()) {
            $templateField.addClass('bdtc-field-error');
        }
        
        if (!$rule.find('select[name^="bdtc_rules"][name$="[post_types][]"]').val() || 
            $rule.find('select[name^="bdtc_rules"][name$="[post_types][]"]').val().length === 0) {
            $postTypesField.addClass('bdtc-field-error');
        }
    }

    // Add new rule
    $('#bdtc-add-rule').on('click', function() {
        // Check if there are any existing rules
        const $existingRules = $('.bdtc-rule');
        
        if ($existingRules.length > 0) {
            // Check if the last rule is complete
            const $lastRule = $existingRules.last();
            
            if (!isRuleComplete($lastRule)) {
                showNotice('Please complete the current rule before adding a new one. Template and at least one post type are required.', 'error');
                highlightIncompleteFields($lastRule);
                
                // Scroll to the last rule
                $('html, body').animate({
                    scrollTop: $lastRule.offset().top - 50
                }, 500);
                
                return;
            }
        }

        $.ajax({
            url: bdtcAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'bdtc_add_rule',
                nonce: bdtcAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice(response.data.message, 'success');
                    location.reload(); // Reload to show new rule
                } else {
                    showNotice(response.data, 'error');
                }
            },
            error: function() {
                showNotice('An error occurred while adding the rule.', 'error');
            }
        });
    });

    // Delete rule
    $('.bdtc-delete-rule').on('click', function() {
        if (!confirm('Are you sure you want to delete this rule?')) {
            return;
        }

        const index = $(this).data('index');
        $.ajax({
            url: bdtcAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'bdtc_delete_rule',
                nonce: bdtcAjax.nonce,
                index: index
            },
            success: function(response) {
                if (response.success) {
                    showNotice(response.data.message, 'success');
                    location.reload(); // Reload to update rules
                } else {
                    showNotice(response.data, 'error');
                }
            },
            error: function() {
                showNotice('An error occurred while deleting the rule.', 'error');
            }
        });
    });

    // Save rules
    $('#bdtc-save-rules').on('click', function() {
        const rules = [];
        let hasIncompleteRules = false;
        
        $('.bdtc-rule').each(function() {
            const $rule = $(this);
            const index = $rule.data('index');
            
            // Check if rule is complete
            if (!isRuleComplete($rule)) {
                hasIncompleteRules = true;
                highlightIncompleteFields($rule);
            }
            
            rules.push({
                template_id: $rule.find('select[name^="bdtc_rules"][name$="[template_id]"]').val(),
                post_types: $rule.find('select[name^="bdtc_rules"][name$="[post_types][]"]').val() || [],
                user_role: $rule.find('select[name^="bdtc_rules"][name$="[user_role]"]').val(),
                tax_term_ids: $rule.find('select[name^="bdtc_rules"][name$="[tax_term_ids][]"]').val() || [],
                priority: parseInt($rule.find('input[name^="bdtc_rules"][name$="[priority]"]').val()) || 0
            });
        });

        if (hasIncompleteRules) {
            showNotice('Please complete all rules before saving. Template and at least one post type are required for each rule.', 'error');
            return;
        }

        $.ajax({
            url: bdtcAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'bdtc_update_rules',
                nonce: bdtcAjax.nonce,
                rules: rules
            },
            success: function(response) {
                if (response.success) {
                    showNotice(response.data.message, 'success');
                } else {
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('An error occurred while saving the rules.', 'error');
            }
        });
    });

    // Reset rules
    $('#bdtc-reset-rules').on('click', function() {
        if (!confirm('Are you sure you want to reset all rules? This action cannot be undone.')) {
            return;
        }

        $.ajax({
            url: bdtcAjax.ajaxurl,
            type: 'POST',
            data: {
                action: 'bdtc_reset_rules',
                nonce: bdtcAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    showNotice(response.data.message, 'success');
                    location.reload(); // Reload to show empty state
                } else {
                    showNotice(response.data, 'error');
                }
            },
            error: function() {
                showNotice('An error occurred while resetting the rules.', 'error');
            }
        });
    });

    // Helper function to show notices
    function showNotice(message, type) {
        const $notice = $('#bdtc-notice');
        $notice
            .removeClass('notice-success notice-error')
            .addClass('notice-' + type)
            .html('<p>' + message + '</p>')
            .show();

        // Scroll to notice
        $('html, body').animate({
            scrollTop: $notice.offset().top - 50
        }, 500);

        // Hide notice after 5 seconds
        setTimeout(function() {
            $notice.fadeOut();
        }, 5000);
    }
}); 